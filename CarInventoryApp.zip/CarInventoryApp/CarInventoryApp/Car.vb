﻿' Author: Domenic Catalano
' Date: March 11, 2020
' Description: This class represents car objects with properties for the make, model, year, and price.

Option Strict On

Public Class Car

#Region "Variable Declarations"
    Private Shared carCount As Integer = 0
    Private carIdentNum As String = String.Empty
    Private carMake As String = String.Empty
    Private carModel As String = String.Empty
    Private carYear As Integer = 0
    Private carPrice As Decimal = 0.0D
    Private carIsNew As Boolean = True

#End Region

#Region "Constructors"
    ''' <summary>
    ''' Default contructor; just increments the carCount.
    ''' </summary>
    Friend Sub New()
        carCount += 1
        carIdentNum = carCount.ToString()
    End Sub

    ''' <summary>
    ''' Parametrized constructor: sets all class values based on arguments passed in
    ''' </summary>
    ''' <param name="makeValue"></param>
    ''' <param name="modelValue"></param>
    ''' <param name="yearValue"></param>
    ''' <param name="priceValue"></param>
    ''' <param name="statusValue"></param>
    Friend Sub New(makeValue As String, modelValue As String, yearValue As Integer, priceValue As Decimal, statusValue As Boolean)
        Me.New()
        carMake = makeValue
        carModel = modelValue
        carYear = yearValue
        carPrice = priceValue
        carIsNew = statusValue
    End Sub

#End Region

#Region "Property Procedures"
    ''' <summary>
    ''' Returns amount of car objects
    ''' </summary>
    ''' <returns>Amount of car objects</returns>
    Friend Shared ReadOnly Property Count() As Integer
        Get
            Return carCount
        End Get
    End Property

    ''' <summary>
    ''' Returns car identification number
    ''' </summary>
    ''' <returns>Car identification number</returns>
    Friend ReadOnly Property ID() As String
        Get
            Return carIdentNum
        End Get
    End Property

    ''' <summary>
    ''' Will get and set a cars manufacturer
    ''' </summary>
    ''' <returns>Car manufacturer name</returns>
    Friend Property Make() As String
        Get
            Return carMake
        End Get
        Set(value As String)
            carMake = value
        End Set
    End Property

    ''' <summary>
    ''' Will get and set a cars manufacturer model name
    ''' </summary>
    ''' <returns>Car model name</returns>
    Friend Property Model() As String
        Get
            Return carModel
        End Get
        Set(value As String)
            carModel = value
        End Set
    End Property

    ''' <summary>
    ''' Gets and sets the cars production year
    ''' </summary>
    ''' <returns>Cars production year</returns>
    Friend Property Year() As Integer
        Get
            Return carYear
        End Get
        Set(value As Integer)
            carYear = value
        End Set
    End Property

    ''' <summary>
    ''' Gets and sets a cars price
    ''' </summary>
    ''' <returns>Cars price</returns>
    Friend Property Price() As Decimal
        Get
            Return carPrice
        End Get
        Set(value As Decimal)
            carPrice = value
        End Set
    End Property

    ''' <summary>
    ''' Gets and sets status of car; whether it's new or not
    ''' </summary>
    ''' <returns>Car condition status</returns>
    Friend Property IsNew() As Boolean
        Get
            Return carIsNew
        End Get
        Set(value As Boolean)
            carIsNew = value
        End Set
    End Property

#End Region

#Region "Methods"

    Friend Function GetCarData() As String
        ' First Method: In line if statement
        Return If(carIsNew, "New", "Used").ToString() & " " & carYear.ToString() & " " & carMake & " " & " for " & carPrice.ToString("c")

        ' Second Method: Regular if statement
        'If carIsNew Then
        'Return "New" & " " & carYear.ToString() & " " & carMake & " " & carModel & " for " & carPrice.ToString("c")
        'Else
        'Return "Used" & " " & carYear.ToString() & " " & carMake & " " & carModel & " for " & carPrice.ToString("c")
        'End If
    End Function

#End Region
End Class
