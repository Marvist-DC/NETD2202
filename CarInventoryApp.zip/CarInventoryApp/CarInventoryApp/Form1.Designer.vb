﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmCarInventoryApp
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.cmbMake = New System.Windows.Forms.ComboBox()
        Me.tbModel = New System.Windows.Forms.TextBox()
        Me.lblMake = New System.Windows.Forms.Label()
        Me.lblModel = New System.Windows.Forms.Label()
        Me.btnEnter = New System.Windows.Forms.Button()
        Me.lblYear = New System.Windows.Forms.Label()
        Me.lblPrice = New System.Windows.Forms.Label()
        Me.lblNew = New System.Windows.Forms.Label()
        Me.lblResult = New System.Windows.Forms.Label()
        Me.tbPrice = New System.Windows.Forms.TextBox()
        Me.chkNew = New System.Windows.Forms.CheckBox()
        Me.btnReset = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.lvwOutput = New System.Windows.Forms.ListView()
        Me.colNew = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colID = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colMake = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colModel = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colYear = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colPrice = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.nmYear = New System.Windows.Forms.NumericUpDown()
        CType(Me.nmYear, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'cmbMake
        '
        Me.cmbMake.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbMake.FormattingEnabled = True
        Me.cmbMake.Items.AddRange(New Object() {"Audi", "BMW", "Cadillac", "Ford", "General Motors", "Honda", "Hyundai", "Volkswagen"})
        Me.cmbMake.Location = New System.Drawing.Point(57, 6)
        Me.cmbMake.Name = "cmbMake"
        Me.cmbMake.Size = New System.Drawing.Size(121, 21)
        Me.cmbMake.TabIndex = 1
        Me.ToolTip1.SetToolTip(Me.cmbMake, "Select a car make")
        '
        'tbModel
        '
        Me.tbModel.Location = New System.Drawing.Point(57, 33)
        Me.tbModel.Name = "tbModel"
        Me.tbModel.Size = New System.Drawing.Size(121, 20)
        Me.tbModel.TabIndex = 3
        Me.ToolTip1.SetToolTip(Me.tbModel, "Enter car model information")
        '
        'lblMake
        '
        Me.lblMake.Location = New System.Drawing.Point(12, 4)
        Me.lblMake.Name = "lblMake"
        Me.lblMake.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblMake.Size = New System.Drawing.Size(39, 23)
        Me.lblMake.TabIndex = 0
        Me.lblMake.Text = "Make:"
        Me.lblMake.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblModel
        '
        Me.lblModel.Location = New System.Drawing.Point(12, 30)
        Me.lblModel.Name = "lblModel"
        Me.lblModel.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblModel.Size = New System.Drawing.Size(39, 23)
        Me.lblModel.TabIndex = 2
        Me.lblModel.Text = "&Model:"
        Me.lblModel.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'btnEnter
        '
        Me.btnEnter.Location = New System.Drawing.Point(109, 356)
        Me.btnEnter.Name = "btnEnter"
        Me.btnEnter.Size = New System.Drawing.Size(75, 23)
        Me.btnEnter.TabIndex = 12
        Me.btnEnter.Text = "&Enter"
        Me.ToolTip1.SetToolTip(Me.btnEnter, "Click to enter the information into the list")
        Me.btnEnter.UseVisualStyleBackColor = True
        '
        'lblYear
        '
        Me.lblYear.Location = New System.Drawing.Point(12, 62)
        Me.lblYear.Name = "lblYear"
        Me.lblYear.Size = New System.Drawing.Size(39, 13)
        Me.lblYear.TabIndex = 4
        Me.lblYear.Text = "Year:"
        Me.lblYear.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblPrice
        '
        Me.lblPrice.Location = New System.Drawing.Point(12, 89)
        Me.lblPrice.Name = "lblPrice"
        Me.lblPrice.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblPrice.Size = New System.Drawing.Size(39, 13)
        Me.lblPrice.TabIndex = 6
        Me.lblPrice.Text = "&Price:"
        Me.lblPrice.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblNew
        '
        Me.lblNew.Location = New System.Drawing.Point(12, 112)
        Me.lblNew.Name = "lblNew"
        Me.lblNew.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblNew.Size = New System.Drawing.Size(39, 13)
        Me.lblNew.TabIndex = 8
        Me.lblNew.Text = "&New:"
        Me.lblNew.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblResult
        '
        Me.lblResult.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblResult.Location = New System.Drawing.Point(12, 272)
        Me.lblResult.Name = "lblResult"
        Me.lblResult.Size = New System.Drawing.Size(334, 81)
        Me.lblResult.TabIndex = 11
        '
        'tbPrice
        '
        Me.tbPrice.Location = New System.Drawing.Point(57, 86)
        Me.tbPrice.Name = "tbPrice"
        Me.tbPrice.Size = New System.Drawing.Size(121, 20)
        Me.tbPrice.TabIndex = 7
        Me.ToolTip1.SetToolTip(Me.tbPrice, "Enter the price of the car")
        '
        'chkNew
        '
        Me.chkNew.AutoSize = True
        Me.chkNew.Location = New System.Drawing.Point(57, 112)
        Me.chkNew.Name = "chkNew"
        Me.chkNew.Size = New System.Drawing.Size(15, 14)
        Me.chkNew.TabIndex = 9
        Me.ToolTip1.SetToolTip(Me.chkNew, "Check this box if the car is new")
        Me.chkNew.UseVisualStyleBackColor = True
        '
        'btnReset
        '
        Me.btnReset.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnReset.Location = New System.Drawing.Point(190, 356)
        Me.btnReset.Name = "btnReset"
        Me.btnReset.Size = New System.Drawing.Size(75, 23)
        Me.btnReset.TabIndex = 13
        Me.btnReset.Text = "&Reset"
        Me.ToolTip1.SetToolTip(Me.btnReset, "Click to reset the form")
        Me.btnReset.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(271, 356)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(75, 23)
        Me.btnExit.TabIndex = 14
        Me.btnExit.Text = "E&xit"
        Me.ToolTip1.SetToolTip(Me.btnExit, "Click to exit")
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'lvwOutput
        '
        Me.lvwOutput.CheckBoxes = True
        Me.lvwOutput.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.colNew, Me.colID, Me.colMake, Me.colModel, Me.colYear, Me.colPrice})
        Me.lvwOutput.FullRowSelect = True
        Me.lvwOutput.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable
        Me.lvwOutput.HideSelection = False
        Me.lvwOutput.Location = New System.Drawing.Point(12, 129)
        Me.lvwOutput.MultiSelect = False
        Me.lvwOutput.Name = "lvwOutput"
        Me.lvwOutput.Size = New System.Drawing.Size(334, 140)
        Me.lvwOutput.TabIndex = 10
        Me.lvwOutput.UseCompatibleStateImageBehavior = False
        Me.lvwOutput.View = System.Windows.Forms.View.Details
        '
        'colNew
        '
        Me.colNew.Text = "New"
        Me.colNew.Width = 55
        '
        'colID
        '
        Me.colID.Text = "ID"
        Me.colID.Width = 55
        '
        'colMake
        '
        Me.colMake.Text = "Make"
        Me.colMake.Width = 55
        '
        'colModel
        '
        Me.colModel.Text = "Model"
        Me.colModel.Width = 55
        '
        'colYear
        '
        Me.colYear.Text = "Year"
        Me.colYear.Width = 55
        '
        'colPrice
        '
        Me.colPrice.Text = "Price"
        Me.colPrice.Width = 55
        '
        'nmYear
        '
        Me.nmYear.Location = New System.Drawing.Point(57, 59)
        Me.nmYear.Maximum = New Decimal(New Integer() {2020, 0, 0, 0})
        Me.nmYear.Minimum = New Decimal(New Integer() {1920, 0, 0, 0})
        Me.nmYear.Name = "nmYear"
        Me.nmYear.Size = New System.Drawing.Size(121, 20)
        Me.nmYear.TabIndex = 5
        Me.nmYear.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.nmYear.Value = New Decimal(New Integer() {2020, 0, 0, 0})
        '
        'frmCarInventoryApp
        '
        Me.AcceptButton = Me.btnEnter
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.CancelButton = Me.btnReset
        Me.ClientSize = New System.Drawing.Size(358, 387)
        Me.Controls.Add(Me.nmYear)
        Me.Controls.Add(Me.lvwOutput)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnReset)
        Me.Controls.Add(Me.chkNew)
        Me.Controls.Add(Me.tbPrice)
        Me.Controls.Add(Me.lblResult)
        Me.Controls.Add(Me.lblNew)
        Me.Controls.Add(Me.lblPrice)
        Me.Controls.Add(Me.lblYear)
        Me.Controls.Add(Me.btnEnter)
        Me.Controls.Add(Me.lblModel)
        Me.Controls.Add(Me.lblMake)
        Me.Controls.Add(Me.tbModel)
        Me.Controls.Add(Me.cmbMake)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmCarInventoryApp"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Car Inventory"
        CType(Me.nmYear, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents cmbMake As ComboBox
    Friend WithEvents tbModel As TextBox
    Friend WithEvents lblMake As Label
    Friend WithEvents lblModel As Label
    Friend WithEvents btnEnter As Button
    Friend WithEvents lblYear As Label
    Friend WithEvents lblPrice As Label
    Friend WithEvents lblNew As Label
    Friend WithEvents lblResult As Label
    Friend WithEvents tbPrice As TextBox
    Friend WithEvents chkNew As CheckBox
    Friend WithEvents btnReset As Button
    Friend WithEvents btnExit As Button
    Friend WithEvents ToolTip1 As ToolTip
    Friend WithEvents lvwOutput As ListView
    Friend WithEvents colNew As ColumnHeader
    Friend WithEvents colID As ColumnHeader
    Friend WithEvents colMake As ColumnHeader
    Friend WithEvents colModel As ColumnHeader
    Friend WithEvents colYear As ColumnHeader
    Friend WithEvents colPrice As ColumnHeader
    Friend WithEvents nmYear As NumericUpDown
End Class
