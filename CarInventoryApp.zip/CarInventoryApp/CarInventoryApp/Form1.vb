﻿' Author: Domenic Catalano
' Date: March 11, 2020
' Description: This application allows a user to input information regarding cars into a form to add to a list.

Option Strict On

Public Class frmCarInventoryApp

    Private carList As New SortedList                           ' This will be a collection of all the cars entered into the form
    Private currentCarIdentNumber As String = String.Empty      ' Currenttly selected car identification number
    Private editMode As Boolean = False                         ' Change to true if you want to allow user to change New/Used
    ' checkbox in listview

    Private Sub frmCarInventoryApp_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
    ''' <summary>
    ''' This event will close the form upon triggering the exit button
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()  'Closes the form
    End Sub

    ''' <summary>
    ''' Calls the reset function upon button click to reset the form to its
    ''' default state
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub btnReset_Click(sender As Object, e As EventArgs) Handles btnReset.Click

        ' Call the reset function
        Reset()

    End Sub

#Region "Reset Button Sub"
    ''' <summary>
    ''' Resets the form to its default state
    ''' </summary>
    Private Sub Reset()
        cmbMake.SelectedIndex = -1
        tbModel.Text = String.Empty
        nmYear.Value = 2020
        tbPrice.Text = String.Empty
        chkNew.Checked = False
        lblResult.Text = String.Empty

        currentCarIdentNumber = String.Empty

    End Sub
#End Region

    ''' <summary>
    ''' This will validate entry, check data selected in the controls, and create a car object
    ''' using the parameterized constructor.
    ''' </summary>
    ''' <param name="sender">Object</param>
    ''' <param name="e">EventArgs</param>
    Private Sub btnEnter_Click(sender As Object, e As EventArgs) Handles btnEnter.Click

        Dim car As Car                      ' Declare car class
        Dim carItem As ListViewItem         ' Declare ListViewItem class

        ' Input Validation
        If IsValid() = True Then

            ' Set edit flag to true
            editMode = True

            ' Let the user know the input was successfully accepted
            lblResult.Text = "Entry Successful!"

            ' Check if the current car identification number has no value
            ' If it doesn't then this is a new entry
            If currentCarIdentNumber.Trim.Length = 0 Then

                ' Create a new car object in the parameterized constructor
                car = New Car(cmbMake.Text, tbModel.Text, CInt(nmYear.Value), CDec(tbPrice.Text), chkNew.Checked)

                ' Add the car to the carList collection
                carList.Add(car.ID.ToString(), car)

                ' If the current car identification number has a value
                ' Then the user selected an entry in the list view
                ' Update the data
            Else
                ' Get the car from the collection using it's unique number
                car = CType(carList.Item(currentCarIdentNumber), Car)

                ' Update the data from the controls
                car.Make = cmbMake.Text
                car.Model = tbModel.Text
                car.Year = CInt(nmYear.Value)
                car.Price = CDec(tbPrice.Text)
                car.IsNew = chkNew.Checked

            End If

            ' Clear items from list view
            lvwOutput.Items.Clear()

            ' Loop through the carList collection and populate the list view
            For Each carEntry As DictionaryEntry In carList

                ' Create new list view item
                carItem = New ListViewItem()

                ' Get a car from the list
                car = CType(carEntry.Value, Car)

                ' Assign values
                carItem.Checked = car.IsNew
                carItem.SubItems.Add(car.ID.ToString())
                carItem.SubItems.Add(car.Make)
                carItem.SubItems.Add(car.Model)
                carItem.SubItems.Add(car.Year.ToString())
                carItem.SubItems.Add(car.Price.ToString())

                ' Add newly created and populated ListViewItem to the listview control
                lvwOutput.Items.Add(carItem)

            Next carEntry

            ' Clear the controls
            Reset()

            ' Turn editMode off
            editMode = False

        End If

    End Sub

#Region "Input Validation Function"
    ''' <summary>
    ''' This will be used to check if the input entered is valid
    ''' </summary>
    ''' <returns></returns>
    Private Function IsValid() As Boolean

        Dim returnValue As Boolean = True               ' Whether there is an error or not
        Dim errorMessage As String = String.Empty       ' Will hold error message and instructions to user
        Dim priceCheck As Decimal

        ' If make was not selected
        If cmbMake.SelectedIndex = -1 Then

            ' Send error message
            errorMessage += "Please select the car's make." + vbCrLf

            ' Set return value to false
            returnValue = False

        End If

        ' If model was not entered
        If tbModel.Text.Trim.Length = 0 Then

            ' Send error message
            errorMessage += "Please enter the car's model." + vbCrLf

            ' Set return value to false
            returnValue = False

        End If

        ' If price was not entered
        If tbPrice.Text.Trim.Length = 0 Then

            ' Send error message
            errorMessage += "Please enter the car's price." + vbCrLf

            ' Set return value to false
            returnValue = False

            ' If the price is not numeric
        ElseIf Not Decimal.TryParse(tbPrice.Text, priceCheck) Then

            ' Send error message
            errorMessage += "Please enter a valid price." + vbCrLf

            ' Set return value to false
            returnValue = False

            ' If the price is less than or equal to 0
        ElseIf priceCheck <= 0 Then

            ' Send error message
            errorMessage += "Please enter price greater than 0." + vbCrLf

            ' Set return value to false
            returnValue = False

        End If

        ' Check if there were any errors
        If returnValue = False Then

            ' Show error messages
            lblResult.Text = "ERRORS" & vbCrLf & errorMessage

        End If

        ' Return the boolean value to determine whether input passed validation
        Return returnValue

    End Function
#End Region

#Region "Edit Mode"
    ''' <summary>
    ''' This will prevent the user from altering the New checkbox from within the listview
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub lvwOutput_ItemCheck(sender As Object, e As ItemCheckEventArgs) Handles lvwOutput.ItemCheck

        ' If editmode is set to false
        If editMode = False Then

            ' Set the new value to the current value so user cannot change in list view
            e.NewValue = e.CurrentValue

        End If
    End Sub
#End Region

#Region "Selected Index"
    Private Sub lvwOutput_SelectedIndexChanged(sender As Object, e As EventArgs) Handles lvwOutput.SelectedIndexChanged

        ' This constant will hold the index of the car identification number
        Const identSubItemIndex = 1

        ' Get the car identification number
        currentCarIdentNumber = lvwOutput.Items(lvwOutput.FocusedItem.Index).SubItems(identSubItemIndex).Text

        ' Use the identification number to get the car information from the collection object
        Dim car As Car = CType(carList.Item(currentCarIdentNumber), Car)

        ' Set the controls on the form to currently selected cars information
        cmbMake.Text = car.Make             ' Get the make and set it to the combo box
        tbModel.Text = car.Model            ' Get the model and set it to the textbox
        nmYear.Value = car.Year             ' Get the year and set it to the numeric up down
        tbPrice.Text = CStr(car.Price)      ' Get the price, convert to string and set it to the textbox
        chkNew.Checked = car.IsNew          ' Get the new/used status and set it to the checkbox

        lblResult.Text = car.GetCarData()   ' Display the information in a string in the result label

    End Sub
#End Region


End Class
