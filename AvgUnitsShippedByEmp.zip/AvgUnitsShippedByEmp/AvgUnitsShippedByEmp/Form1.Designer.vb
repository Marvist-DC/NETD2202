﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmAvgUnitsShip
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.lblDay = New System.Windows.Forms.Label()
        Me.lblUnits = New System.Windows.Forms.Label()
        Me.txtUnitsInput = New System.Windows.Forms.TextBox()
        Me.lblEmployee3 = New System.Windows.Forms.Label()
        Me.lblEmployee2 = New System.Windows.Forms.Label()
        Me.lblEmployee1 = New System.Windows.Forms.Label()
        Me.txtEmployee3Units = New System.Windows.Forms.TextBox()
        Me.txtEmployee2Units = New System.Windows.Forms.TextBox()
        Me.txtEmployee1Units = New System.Windows.Forms.TextBox()
        Me.lblEmployee3Output = New System.Windows.Forms.Label()
        Me.lblEmployee2Output = New System.Windows.Forms.Label()
        Me.lblEmployee1Output = New System.Windows.Forms.Label()
        Me.lblAverageOutput = New System.Windows.Forms.Label()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.btnReset = New System.Windows.Forms.Button()
        Me.btnEnter = New System.Windows.Forms.Button()
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.SuspendLayout()
        '
        'lblDay
        '
        Me.lblDay.AutoSize = True
        Me.lblDay.Location = New System.Drawing.Point(13, 13)
        Me.lblDay.Name = "lblDay"
        Me.lblDay.Size = New System.Drawing.Size(38, 13)
        Me.lblDay.TabIndex = 0
        Me.lblDay.Text = "Day 1:"
        '
        'lblUnits
        '
        Me.lblUnits.AutoSize = True
        Me.lblUnits.Location = New System.Drawing.Point(13, 39)
        Me.lblUnits.Name = "lblUnits"
        Me.lblUnits.Size = New System.Drawing.Size(34, 13)
        Me.lblUnits.TabIndex = 1
        Me.lblUnits.Text = "Units:"
        '
        'txtUnitsInput
        '
        Me.txtUnitsInput.Location = New System.Drawing.Point(53, 36)
        Me.txtUnitsInput.Name = "txtUnitsInput"
        Me.txtUnitsInput.Size = New System.Drawing.Size(53, 20)
        Me.txtUnitsInput.TabIndex = 2
        Me.ToolTip1.SetToolTip(Me.txtUnitsInput, "Enter units sold")
        '
        'lblEmployee3
        '
        Me.lblEmployee3.Location = New System.Drawing.Point(189, 71)
        Me.lblEmployee3.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblEmployee3.Name = "lblEmployee3"
        Me.lblEmployee3.Size = New System.Drawing.Size(73, 19)
        Me.lblEmployee3.TabIndex = 10
        Me.lblEmployee3.Text = "Employee 3"
        Me.lblEmployee3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblEmployee2
        '
        Me.lblEmployee2.Location = New System.Drawing.Point(110, 71)
        Me.lblEmployee2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblEmployee2.Name = "lblEmployee2"
        Me.lblEmployee2.Size = New System.Drawing.Size(73, 19)
        Me.lblEmployee2.TabIndex = 7
        Me.lblEmployee2.Text = "Employee 2"
        Me.lblEmployee2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblEmployee1
        '
        Me.lblEmployee1.Location = New System.Drawing.Point(30, 71)
        Me.lblEmployee1.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblEmployee1.Name = "lblEmployee1"
        Me.lblEmployee1.Size = New System.Drawing.Size(73, 19)
        Me.lblEmployee1.TabIndex = 4
        Me.lblEmployee1.Text = "Employee 1"
        Me.lblEmployee1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtEmployee3Units
        '
        Me.txtEmployee3Units.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.txtEmployee3Units.Location = New System.Drawing.Point(188, 95)
        Me.txtEmployee3Units.Margin = New System.Windows.Forms.Padding(2)
        Me.txtEmployee3Units.Multiline = True
        Me.txtEmployee3Units.Name = "txtEmployee3Units"
        Me.txtEmployee3Units.ReadOnly = True
        Me.txtEmployee3Units.Size = New System.Drawing.Size(74, 118)
        Me.txtEmployee3Units.TabIndex = 11
        '
        'txtEmployee2Units
        '
        Me.txtEmployee2Units.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.txtEmployee2Units.Location = New System.Drawing.Point(109, 95)
        Me.txtEmployee2Units.Margin = New System.Windows.Forms.Padding(2)
        Me.txtEmployee2Units.Multiline = True
        Me.txtEmployee2Units.Name = "txtEmployee2Units"
        Me.txtEmployee2Units.ReadOnly = True
        Me.txtEmployee2Units.Size = New System.Drawing.Size(74, 118)
        Me.txtEmployee2Units.TabIndex = 8
        '
        'txtEmployee1Units
        '
        Me.txtEmployee1Units.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.txtEmployee1Units.Location = New System.Drawing.Point(29, 95)
        Me.txtEmployee1Units.Margin = New System.Windows.Forms.Padding(2)
        Me.txtEmployee1Units.Multiline = True
        Me.txtEmployee1Units.Name = "txtEmployee1Units"
        Me.txtEmployee1Units.ReadOnly = True
        Me.txtEmployee1Units.Size = New System.Drawing.Size(74, 118)
        Me.txtEmployee1Units.TabIndex = 5
        '
        'lblEmployee3Output
        '
        Me.lblEmployee3Output.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblEmployee3Output.Location = New System.Drawing.Point(188, 215)
        Me.lblEmployee3Output.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblEmployee3Output.Name = "lblEmployee3Output"
        Me.lblEmployee3Output.Size = New System.Drawing.Size(73, 19)
        Me.lblEmployee3Output.TabIndex = 12
        Me.lblEmployee3Output.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblEmployee2Output
        '
        Me.lblEmployee2Output.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblEmployee2Output.Location = New System.Drawing.Point(109, 215)
        Me.lblEmployee2Output.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblEmployee2Output.Name = "lblEmployee2Output"
        Me.lblEmployee2Output.Size = New System.Drawing.Size(73, 19)
        Me.lblEmployee2Output.TabIndex = 9
        Me.lblEmployee2Output.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblEmployee1Output
        '
        Me.lblEmployee1Output.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblEmployee1Output.Location = New System.Drawing.Point(29, 215)
        Me.lblEmployee1Output.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblEmployee1Output.Name = "lblEmployee1Output"
        Me.lblEmployee1Output.Size = New System.Drawing.Size(73, 19)
        Me.lblEmployee1Output.TabIndex = 6
        Me.lblEmployee1Output.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblAverageOutput
        '
        Me.lblAverageOutput.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblAverageOutput.Location = New System.Drawing.Point(29, 242)
        Me.lblAverageOutput.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblAverageOutput.Name = "lblAverageOutput"
        Me.lblAverageOutput.Size = New System.Drawing.Size(232, 19)
        Me.lblAverageOutput.TabIndex = 13
        Me.lblAverageOutput.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(188, 270)
        Me.btnExit.Margin = New System.Windows.Forms.Padding(2)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(72, 23)
        Me.btnExit.TabIndex = 16
        Me.btnExit.Text = "E&xit"
        Me.ToolTip1.SetToolTip(Me.btnExit, "Click to exit the form")
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'btnReset
        '
        Me.btnReset.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnReset.Location = New System.Drawing.Point(109, 270)
        Me.btnReset.Margin = New System.Windows.Forms.Padding(2)
        Me.btnReset.Name = "btnReset"
        Me.btnReset.Size = New System.Drawing.Size(73, 23)
        Me.btnReset.TabIndex = 15
        Me.btnReset.Text = "&Reset"
        Me.ToolTip1.SetToolTip(Me.btnReset, "Click to reset the form")
        Me.btnReset.UseVisualStyleBackColor = True
        '
        'btnEnter
        '
        Me.btnEnter.Location = New System.Drawing.Point(29, 270)
        Me.btnEnter.Margin = New System.Windows.Forms.Padding(2)
        Me.btnEnter.Name = "btnEnter"
        Me.btnEnter.Size = New System.Drawing.Size(73, 23)
        Me.btnEnter.TabIndex = 14
        Me.btnEnter.Text = "&Enter"
        Me.ToolTip1.SetToolTip(Me.btnEnter, "Click to submit units sold to the form")
        Me.btnEnter.UseVisualStyleBackColor = True
        '
        'frmAvgUnitsShip
        '
        Me.AcceptButton = Me.btnEnter
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.CancelButton = Me.btnReset
        Me.ClientSize = New System.Drawing.Size(291, 301)
        Me.Controls.Add(Me.lblEmployee3Output)
        Me.Controls.Add(Me.lblEmployee2Output)
        Me.Controls.Add(Me.lblEmployee1Output)
        Me.Controls.Add(Me.lblAverageOutput)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnReset)
        Me.Controls.Add(Me.btnEnter)
        Me.Controls.Add(Me.lblEmployee3)
        Me.Controls.Add(Me.lblEmployee2)
        Me.Controls.Add(Me.lblEmployee1)
        Me.Controls.Add(Me.txtEmployee3Units)
        Me.Controls.Add(Me.txtEmployee2Units)
        Me.Controls.Add(Me.txtEmployee1Units)
        Me.Controls.Add(Me.txtUnitsInput)
        Me.Controls.Add(Me.lblUnits)
        Me.Controls.Add(Me.lblDay)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmAvgUnitsShip"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Average Units Shipped By Employee"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblDay As Label
    Friend WithEvents lblUnits As Label
    Friend WithEvents txtUnitsInput As TextBox
    Friend WithEvents lblEmployee3 As Label
    Friend WithEvents lblEmployee2 As Label
    Friend WithEvents lblEmployee1 As Label
    Friend WithEvents txtEmployee3Units As TextBox
    Friend WithEvents txtEmployee2Units As TextBox
    Friend WithEvents txtEmployee1Units As TextBox
    Friend WithEvents lblEmployee3Output As Label
    Friend WithEvents lblEmployee2Output As Label
    Friend WithEvents lblEmployee1Output As Label
    Friend WithEvents lblAverageOutput As Label
    Friend WithEvents btnExit As Button
    Friend WithEvents btnReset As Button
    Friend WithEvents btnEnter As Button
    Friend WithEvents ToolTip1 As ToolTip
End Class
