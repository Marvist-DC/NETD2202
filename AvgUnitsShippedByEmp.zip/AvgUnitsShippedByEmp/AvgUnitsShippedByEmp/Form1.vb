﻿' Author: Domenic Catalano
' Date: Feb 26, 2020
' Description: Takes input of units shipped, validates then adds it to a list.
' After 7 values have been entered and validated it will calculate an average
' and display it to the user. It will then prompt for the next employee's data.
' Once all employee data has been entered a total average will be calculated and
' displayed. Functionality to reset and exit the form is also implemented.

Option Strict On

Public Class frmAvgUnitsShip

#Region "Global Variables"
    Dim day As Integer = 0              ' Variable to hold current day being entered
    Dim emp As Integer = 0              ' Variable to hold current employee being entered

    Const MinUnits = 0                  ' Minimum allowable units sold
    Const MaxUnits = 5000               ' Maximum allowable units sold

    Dim empTotalUnits As Integer        ' Holds the total units sold per employee
    Dim totalUnitsSold As Integer       ' Holds running total of all units sold

    Dim empAvgUnits As Double           ' Holds average units sold per employee
    Dim totalAvgUnits As Double         ' Holds total average units sold

    Dim empArray(2, 6) As Integer       ' Array to store employee data

    Dim textboxArray() As TextBox       ' Array of output textboxes
    Dim outputLabelArray() As Label     ' Array of the output average labels for each employee
#End Region

    ''' <summary>
    ''' Closes form
    ''' </summary>
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    ''' <summary>
    ''' When the form loads, populate textboxArray() and outputLabelArray()
    ''' </summary>
    Private Sub frmAvgUnitsShip_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        textboxArray = {txtEmployee1Units, txtEmployee2Units, txtEmployee3Units}
        outputLabelArray = {lblEmployee1Output, lblEmployee2Output, lblEmployee3Output}
    End Sub
    ''' <summary>
    ''' Method to be called when the reset button is clicked. It will reset the form to its default state
    ''' </summary>
    Sub SetDefaults()

        ' Clear textboxes and output labels
        txtUnitsInput.Clear()
        txtEmployee1Units.Clear()
        txtEmployee2Units.Clear()
        txtEmployee3Units.Clear()
        lblEmployee1Output.Text = String.Empty
        lblEmployee2Output.Text = String.Empty
        lblEmployee3Output.Text = String.Empty
        lblAverageOutput.Text = String.Empty

        ' Enable the disabled controls
        txtUnitsInput.Enabled = True
        btnEnter.Enabled = True

        ' Reset default values and set focus back to input control
        day = 0
        emp = 0
        lblDay.Text = "Day " & (day + 1)
        empTotalUnits = 0
        totalUnitsSold = 0
        txtUnitsInput.Focus()
    End Sub
    ''' <summary>
    ''' Calls SetDefaults() method
    ''' </summary>
    Private Sub btnReset_Click(sender As Object, e As EventArgs) Handles btnReset.Click
        SetDefaults()
    End Sub

    ''' <summary>
    ''' Input validation, record validated entries and calulates averages
    ''' </summary>
    Private Sub btnEnter_Click(sender As Object, e As EventArgs) Handles btnEnter.Click

        ' Variables
        Const DaysPerEmp = 7        ' Constant that defines the maximum days of input for each employee
        Const NumOfEmps = 3         ' Constant that defines the maximum number of employees this form supports

        ' Input validation
        If Integer.TryParse(txtUnitsInput.Text, empArray(emp, day)) Then

            If empArray(emp, day) >= MinUnits And empArray(emp, day) <= MaxUnits Then

                ' Output values if they are valid
                textboxArray(emp).Text &= empArray(emp, day) & vbCrLf

                ' Increase the day counter by 1
                day += 1
                lblDay.Text = "Day: " & (day + 1)

                ' Clear the input textbox
                txtUnitsInput.Clear()

                ' If day equals 7, calculate the average and display it to the user
                If day = DaysPerEmp Then

                    ' Ensure the total units for an employee is cleared before starting calculation
                    empTotalUnits = 0

                    ' Calculate total for an employee
                    For dayCounter As Integer = 0 To DaysPerEmp - 1
                        empTotalUnits += empArray(emp, dayCounter)
                    Next

                    ' Calculate and output the average to the user
                    empAvgUnits = empTotalUnits / DaysPerEmp
                    outputLabelArray(emp).Text = "Avg: " & Math.Round(empAvgUnits, 2)   ' Output and round to 2 decimal places

                    ' Move to the next employee
                    emp += 1

                    ' Reset the day back to 0
                    day = 0
                    lblDay.Text = "Day: " & (day + 1)

                    ' If the third employee has been reached, then calculate the total average
                    If emp = NumOfEmps Then

                        ' Add all units sold together
                        For Each day In empArray
                            totalUnitsSold += day
                        Next

                        ' Calculate and display the average to the user
                        totalAvgUnits = totalUnitsSold / empArray.Length
                        lblAverageOutput.Text = "Avg: " & Math.Round(totalAvgUnits, 2)

                        ' Disable input textbox and 'Enter' button. Apply focus to reset
                        txtUnitsInput.Enabled = False
                        btnEnter.Enabled = False
                        btnReset.Focus()

                        lblDay.Text = "Done!"   ' Display 'Done!' in place of the day label when all entries and calculations have completed

                    End If
                End If
                ' If the value entered is not within range
            Else
                MessageBox.Show("Unit entered must be within 0-5000!")
                txtUnitsInput.SelectAll()
                txtUnitsInput.Focus()
            End If
            ' If the value entered is not a whole number, display error message
        Else
            MessageBox.Show("Unit must be entered as a whole number!")
            txtUnitsInput.SelectAll()
            txtUnitsInput.Focus()
        End If
    End Sub
End Class
