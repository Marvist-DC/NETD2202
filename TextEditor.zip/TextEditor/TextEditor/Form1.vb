﻿'   Name: Domenic Catalano
'   Date: April 3, 2020
'   Project Name: Text Editor
'   Description: This windows form application will act like a common text editor

Option Strict On
Imports System.IO
Public Class frmTextEditor

    Dim isFileOpen As Boolean = False               ' Checks if a file is open
    Dim filePath As String = String.Empty           ' File Path

    ''' <summary>
    ''' Handles the event of the About option in the Help menu being clicked.
    ''' </summary>
    Private Sub mnuHelpAbout_Click(sender As Object, e As EventArgs) Handles mnuHelpAbout.Click

        ' Opens a message box upon being clicked
        MessageBox.Show("Text Editor" & vbCrLf & vbCrLf &
                        "By Domenic Catalano" & vbCrLf & vbCrLf &
                        "April 3, 2020")

    End Sub
    ''' <summary>
    ''' Handles the event of the Exit option in the File menu being clicked.
    ''' </summary>
    Private Sub mnuFileExit_Click(sender As Object, e As EventArgs) Handles mnuFileExit.Click

        ' Closes the form when clicked
        Me.Close()

    End Sub

    ''' <summary>
    ''' Handles the event of the New option in the File menu being clicked
    ''' </summary>
    Private Sub mnuFileNew_Click(sender As Object, e As EventArgs) Handles mnuFileNew.Click

        ' Clears the textbox window
        tbTextEditorWindow.Clear()

        isFileOpen = False              ' Set isFileOpen to false
        filePath = String.Empty         ' Empty file path
        UpdateFormTitle()               ' Update form title

    End Sub

    ''' <summary>
    ''' Handles the event of the Open option in the file Menu being clicked
    ''' </summary>
    Private Sub mnuFileOpen_Click(sender As Object, e As EventArgs) Handles mnuFileOpen.Click

        Dim openFile As FileStream
        Dim fileReader As StreamReader

        ' If the okay button is pressed in the open dialog window
        If opdOpen.ShowDialog() = DialogResult.OK Then

            filePath = opdOpen.FileName     ' File path becomes the path of the file in the open window

            ' Update the form title
            UpdateFormTitle()

            isFileOpen = True               ' isFileOpen will now be true

            ' Create a new FileStream, open the path that was given, using only the open file mode
            ' and read file access
            openFile = New FileStream(filePath, FileMode.Open, FileAccess.Read)

            ' Create a file reader
            fileReader = New StreamReader(openFile)

            ' Populate the text editor
            tbTextEditorWindow.Text = fileReader.ReadToEnd

            ' Close the file reader to release resources
            fileReader.Close()

        End If

    End Sub

    ''' <summary>
    ''' Handles the event of the Save option in the File menu being clicked
    ''' </summary>
    Private Sub mnuFileSave_Click(sender As Object, e As EventArgs) Handles mnuFileSave.Click

        ' If there is no file path
        If filePath = String.Empty Then

            ' Evolve into a save as button
            mnuFileSaveAs_Click(sender, e)

        Else

            ' Otherwise, don't evolve. Just overwrite the previous save (i.e file path)
            SaveTextFile(filePath)

        End If


    End Sub

    ''' <summary>
    ''' Handles the event of the Save As option in the File menu being clicked
    ''' </summary>
    Private Sub mnuFileSaveAs_Click(sender As Object, e As EventArgs) Handles mnuFileSaveAs.Click

        ' Sets the filter for the save dialog
        sfdSaveAs.Filter = "Text files (*.txt)|*.txt|All files (*.*)|*.*"

        ' If the okay button is pressed in the open dialog window
        If sfdSaveAs.ShowDialog() = DialogResult.OK Then

            ' Set new file path
            filePath = sfdSaveAs.FileName
            ' Save the file
            SaveTextFile(filePath)

            ' Update the form title
            UpdateFormTitle()
        End If

    End Sub

    ''' <summary>
    ''' Handles the event of the Copy option in the Edit menu being clicked
    ''' </summary>
    Private Sub mnuEditCopy_Click(sender As Object, e As EventArgs) Handles mnuEditCopy.Click

        ' If there is something selected in the textbox, overwrite clipboard
        If tbTextEditorWindow.SelectedText IsNot String.Empty Then

            ' Copy to clipboard
            My.Computer.Clipboard.SetText(tbTextEditorWindow.SelectedText)

        End If

    End Sub

    ''' <summary>
    ''' Handles the event of the Cut option in the Edit menu being clicked
    ''' </summary>
    Private Sub mnuEditCut_Click(sender As Object, e As EventArgs) Handles mnuEditCut.Click

        ' If there is something selected in the textbox, overwrite clipboard
        If tbTextEditorWindow.SelectedText IsNot String.Empty Then

            ' Copy to clipboard
            My.Computer.Clipboard.SetText(tbTextEditorWindow.SelectedText)

            ' Clear the selected text
            tbTextEditorWindow.SelectedText = String.Empty
        End If

    End Sub

    ''' <summary>
    ''' Handles the event of the Paste option in the Edit menu being clicked
    ''' </summary>
    Private Sub mnuEditPaste_Click(sender As Object, e As EventArgs) Handles mnuEditPaste.Click

        ' If the clipboard contains text, then allow paste functionality
        If Clipboard.ContainsText Then

            ' Paste the text from the clipboard
            tbTextEditorWindow.Text = My.Computer.Clipboard.GetText

        End If

    End Sub

    ''' <summary>
    ''' Saves the text file to a specified text file locally
    ''' </summary>
    ''' <param name="path">A full file path as a string</param>
    Friend Sub SaveTextFile(path As String)

        Dim saveFile As FileStream
        Dim fileWriter As StreamWriter

        ' Create a new FileStream, create the path that was given, using only the create file mode
        ' and write file access
        saveFile = New FileStream(filePath, FileMode.Create, FileAccess.Write)

        ' Create a file reader
        fileWriter = New StreamWriter(saveFile)

        ' Save the file
        fileWriter.Write(tbTextEditorWindow.Text)

        ' Close the file reader to release resources
        fileWriter.Close()

    End Sub

    ''' <summary>
    ''' Updates the forms title to include the file path
    ''' </summary>
    Friend Sub UpdateFormTitle()

        ' Default name
        Me.Text = "Text Editor"

        ' If the file path isn't empty
        If Not filePath = String.Empty Then

            ' Add it to the title
            Me.Text &= " - " & filePath

        End If

    End Sub
End Class
